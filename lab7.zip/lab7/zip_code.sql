CREATE TABLE IF NOT EXISTS `zip_code` (
  `zip` int(6) NOT NULL,
  `city` varchar(25) NOT NULL,
  `state` varchar(25) NOT NULL,
  `county` varchar(25) NOT NULL,
  `areaCode` int(5) NOT NULL,
  `latitude` int(5) NOT NULL,
  `longitude` int(5) NOT NULL,
  PRIMARY KEY (`zip`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `zip_code` (`zip`, `city`, `state`, `county`, `areaCode`, `latitude`, `longitude`) VALUES

(95060, 'Santa Cruz', 'CA', 'Santa Cruz County', 408, 37, -122)