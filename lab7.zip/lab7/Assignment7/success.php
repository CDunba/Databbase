
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<title>Courtney Dunbar - Assignment 7</title>
		<link rel="stylesheet" type="text/css" href="style.css">
		<script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
	</head>
	
	<body>
		<div>
			<p>Thank you for registering, Courtney</p>
		</div>
	</body>
</html>